//
//  WIshTopLayoutCell.swift
//  prototype
//
//  Created by cscoi028 on 2017. 8. 16..
//  Copyright © 2017년 B612. All rights reserved.
//

import UIKit

class WIshTopLayoutCell: UITableViewCell {

    @IBOutlet weak var fixedLabel1: UILabel!
    @IBOutlet weak var wastedLAbel: UILabel!
    @IBOutlet weak var fixedLabel2: UILabel!
    
    

}
