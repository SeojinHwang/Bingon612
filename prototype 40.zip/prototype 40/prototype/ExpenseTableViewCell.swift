//
//  ExpenseTableViewCell.swift
//  prototype
//
//  Created by cscoi029 on 2017. 8. 17..
//  Copyright © 2017년 B612. All rights reserved.
//

import UIKit

class ExpenseTableViewCell: UITableViewCell {

    @IBOutlet weak var exDate: UILabel!
    @IBOutlet weak var exContent: UILabel!
    @IBOutlet weak var exPrice: UILabel!

}
