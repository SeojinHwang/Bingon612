//
//  WishTableViewCell.swift
//  prototype
//
//  Created by cscoi027 on 2017. 8. 11..
//  Copyright © 2017년 B612. All rights reserved.
//

import UIKit

class WishTableViewCell: UITableViewCell {

    var wishModalResult: String?

    @IBOutlet weak var number: UILabel!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var buyableNumber: UILabel!

    
         }
