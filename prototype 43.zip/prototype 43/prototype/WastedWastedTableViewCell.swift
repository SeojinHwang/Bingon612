//
//  WastedWastedTableViewCell.swift
//  prototype
//
//  Created by cscoi029 on 2017. 8. 17..
//  Copyright © 2017년 B612. All rights reserved.
//

import UIKit

class WastedWastedTableViewCell: UITableViewCell {


    @IBOutlet weak var wawaDate: UILabel!
    @IBOutlet weak var wawaContent: UILabel!
    @IBOutlet weak var wawaPrice: UILabel!

}
