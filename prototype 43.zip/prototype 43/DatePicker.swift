//
//  DatePicker.swift
//  prototype
//
//  Created by apple on 2017. 8. 9..
//  Copyright © 2017년 B612. All rights reserved.
//

import UIKit

class DatePicker: UIDatePicker {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
